const express = require("express");
const path = require("path");
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/create-preference", async (req, res) => {
  const token = process.env.MP_ACCESS_TOKEN;
  if (!token) return res.status(503).json({ error: "Mercado Pago ainda não configurado. Adicione MP_ACCESS_TOKEN no ambiente do servidor." });

  const { items, payer } = req.body || {};
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: "Carrinho vazio." });

  const preference = {
    items: items.map(item => ({
      id: String(item.id),
      title: String(item.title),
      quantity: Math.max(1, Number(item.quantity) || 1),
      unit_price: Number(item.unit_price),
      currency_id: "BRL"
    })),
    payer: {
      name: payer?.name,
      email: payer?.email,
      phone: payer?.phone
    },
    back_urls: {
      success: process.env.SUCCESS_URL || "https://www.seudominio.com.br/pedido-aprovado",
      failure: process.env.FAILURE_URL || "https://www.seudominio.com.br/pagamento-nao-aprovado",
      pending: process.env.PENDING_URL || "https://www.seudominio.com.br/pagamento-pendente"
    },
    auto_return: "approved",
    statement_descriptor: "ALBERGARA"
  };

  try {
    const response = await fetch("https://api.mercadopago.com/checkout/preferences", {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify(preference)
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.message || "Erro ao criar pagamento no Mercado Pago." });
    res.json({ init_point: data.init_point });
  } catch (error) {
    res.status(500).json({ error: "Falha de comunicação com o provedor de pagamento." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`ALBERGARA no ar em http://localhost:${port}`));
