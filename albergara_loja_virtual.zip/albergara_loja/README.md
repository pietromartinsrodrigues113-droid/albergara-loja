# ALBERGARA — loja virtual

Loja responsiva com catálogo masculino e feminino, sacola/carrinho e integração preparada para Checkout Pro do Mercado Pago.

## Rodar localmente
1. Instale Node.js 18 ou superior.
2. Abra um terminal nesta pasta.
3. Execute `npm install`.
4. Configure a variável de ambiente `MP_ACCESS_TOKEN` com o Access Token da sua conta Mercado Pago.
5. Execute `npm start` e abra `http://localhost:3000`.

No macOS/Linux:
`MP_ACCESS_TOKEN="SEU_ACCESS_TOKEN" npm start`

No Windows PowerShell:
`$env:MP_ACCESS_TOKEN="SEU_ACCESS_TOKEN"; npm start`

## Antes de vender de verdade
- Crie/acesse sua conta Mercado Pago e obtenha as credenciais de produção.
- Configure `MP_ACCESS_TOKEN` somente no servidor. Nunca coloque esse token no HTML ou compartilhe publicamente.
- Troque os produtos, preços e descrições de exemplo em `public/index.html`.
- Substitua os ícones ilustrativos por fotos reais dos seus relógios.
- Configure domínio/HTTPS e as URLs de retorno `SUCCESS_URL`, `FAILURE_URL` e `PENDING_URL`.
- Para confirmar pedidos automaticamente, implemente notificações/webhooks do Mercado Pago e valide o pagamento no servidor antes de liberar qualquer produto.
- Defina frete, política de troca/devolução, privacidade, contato e dados da empresa antes de publicar.

**Importante:** o projeto não está recebendo pagamentos ainda. O checkout só funcionará depois de configurar credenciais válidas e publicar o servidor em hospedagem compatível. Os relógios e valores incluídos são exemplos editáveis.
